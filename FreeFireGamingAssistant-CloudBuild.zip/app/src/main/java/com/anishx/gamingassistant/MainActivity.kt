package com.anishx.gamingassistant

import android.Manifest
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    private val projectionManager by lazy {
        getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AssistantScreen(
                    onStartRecording = {
                        val intent = projectionManager.createScreenCaptureIntent()
                        captureLauncher.launch(intent)
                    },
                    onStopRecording = {
                        startService(Intent(this, ScreenRecordService::class.java).apply {
                            action = ScreenRecordService.ACTION_STOP
                        })
                    }
                )
            }
        }
    }

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, ScreenRecordService::class.java).apply {
                    action = ScreenRecordService.ACTION_START
                    putExtra(ScreenRecordService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(ScreenRecordService.EXTRA_RESULT_DATA, result.data)
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
                else startService(serviceIntent)
            }
        }
}

@Composable
private fun AssistantScreen(
    onStartRecording: () -> Unit,
    onStopRecording: () -> Unit
) {
    var recording by remember { mutableStateOf(false) }
    var matches by remember { mutableStateOf("0") }
    var headshots by remember { mutableStateOf("0") }
    var controlStyle by remember { mutableStateOf("Default") }

    val recommendation = remember(matches, headshots, controlStyle) {
        SensitivityAdvisor.recommend(
            matches.toIntOrNull() ?: 0,
            headshots.toIntOrNull() ?: 0,
            controlStyle
        )
    }

    Scaffold { padding ->
        Column(
            Modifier.padding(padding).fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text("ANISH GAMING ASSISTANT", style = MaterialTheme.typography.headlineSmall)
            Text("Free Fire • Record • Review • Tune", style = MaterialTheme.typography.bodyMedium)

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Screen recording", style = MaterialTheme.typography.titleLarge)
                    Text("Android will show its own screen-capture consent prompt.")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled = !recording, onClick = {
                            onStartRecording()
                            recording = true
                        }) { Text("Start recording") }
                        OutlinedButton(enabled = recording, onClick = {
                            onStopRecording()
                            recording = false
                        }) { Text("Stop") }
                    }
                    Text(if (recording) "Recording requested — use the system notification to stop if needed." else "Not recording")
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Match stats", style = MaterialTheme.typography.titleLarge)
                    Text("Enter results from a recent session. The first version uses transparent, rule-based tuning.")
                    OutlinedTextField(matches, { matches = it.filter(Char::isDigit) }, label = { Text("Matches played") })
                    OutlinedTextField(headshots, { headshots = it.filter(Char::isDigit) }, label = { Text("Headshots") })
                    Text("Control style")
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(selected = controlStyle == "Default", onClick = { controlStyle = "Default" }, label = { Text("Default") })
                        FilterChip(selected = controlStyle == "Claw", onClick = { controlStyle = "Claw" }, label = { Text("Claw") })
                    }
                }
            }

            Card {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Sensitivity starting point", style = MaterialTheme.typography.titleLarge)
                    Text("General: ${recommendation.general}")
                    Text("Red Dot: ${recommendation.redDot}")
                    Text("2x Scope: ${recommendation.scope2x}")
                    Text("4x Scope: ${recommendation.scope4x}")
                    Text("Sniper: ${recommendation.sniper}")
                    Text("Free Look: ${recommendation.freeLook}")
                    Divider()
                    Text(recommendation.reason)
                    Text("These are test values, not guaranteed optimal settings. Change one slider at a time and compare several training-ground sessions.",
                        style = MaterialTheme.typography.bodySmall)
                }
            }
            Text("Privacy: recordings stay on the device in this starter build. No gameplay is uploaded.", style = MaterialTheme.typography.bodySmall)
        }
    }
}
