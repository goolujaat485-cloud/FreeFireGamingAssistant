package com.anishx.gamingassistant

data class SensitivityProfile(
    val general: Int,
    val redDot: Int,
    val scope2x: Int,
    val scope4x: Int,
    val sniper: Int,
    val freeLook: Int,
    val reason: String
)

/**
 * Conservative baseline generator. It deliberately avoids claiming to infer
 * perfect settings from a headshot ratio alone. Tune values in small increments.
 */
object SensitivityAdvisor {
    fun recommend(matches: Int, headshots: Int, controlStyle: String): SensitivityProfile {
        val ratio = if (matches > 0) (headshots.toFloat() / matches).coerceIn(0f, 1f) else 0.35f
        val clawOffset = if (controlStyle == "Claw") 3 else 0
        val aimOffset = when {
            ratio < 0.20f -> 5
            ratio > 0.55f -> -3
            else -> 0
        }

        fun clamp(value: Int) = value.coerceIn(0, 200)

        val general = clamp(92 + aimOffset + clawOffset)
        val redDot = clamp(88 + aimOffset + clawOffset)
        val scope2x = clamp(82 + (aimOffset / 2) + clawOffset)
        val scope4x = clamp(72 + (aimOffset / 2))
        val sniper = clamp(48 + (aimOffset / 3))
        val freeLook = clamp(80 + clawOffset)

        val explanation = when {
            matches == 0 -> "Add match stats for a slightly more tailored starting point. Start from your current comfortable settings."
            ratio < 0.20f -> "Your entered headshot count is relatively low. Try a modest General/Red Dot increase, then test drag control."
            ratio > 0.55f -> "Your entered headshot count is high. Try a small reduction if your crosshair often overshoots."
            else -> "Your entered ratio is in the middle band. Keep changes small and prioritize consistency over high sensitivity."
        }

        return SensitivityProfile(
            general, redDot, scope2x, scope4x, sniper, freeLook,
            "$explanation Control preset: $controlStyle. This is a heuristic, not visual AI analysis."
        )
    }
}
