# Anish Gaming Assistant — Free Fire starter

Android Studio project for a consent-based screen recorder and a transparent sensitivity starting-point calculator.

## Build
1. Install Android Studio with Android SDK 35.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Connect an Android 8.0+ device or start an emulator.
5. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

The debug APK is normally produced at `app/build/outputs/apk/debug/app-debug.apk`.

## Included
- Android MediaProjection consent flow for screen recording.
- Foreground media-projection service.
- Local match-stat input and rule-based sensitivity starting points.
- No account login, network upload, game-memory access, or game modification.

## Important limitations
- This starter does **not** yet perform computer-vision analysis of recorded gameplay. It does not claim to detect recoil, crosshair placement, or aim quality automatically.
- The sensitivity calculator is heuristic. Record a few matches, enter your stats, and test small changes manually in Training Ground.
- Android requires explicit screen-capture consent. Microphone capture may require runtime permission on some devices; if recording fails, remove `setAudioSource` / `setAudioEncoder` for silent capture or add a microphone permission flow.
- Android 14+ enforces MediaProjection session rules. Test on the target Android version and handle device-specific encoder limitations before release.
- Do not use this app to automate aiming, inject input, tamper with Free Fire, or bypass game protections.
